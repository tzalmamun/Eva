import { Alert, Button } from 'antd';
import { WhatsAppOutlined } from '@ant-design/icons';

interface SubRenewProps {
  url: string;
  expired: boolean;
}

export default function SubRenew({ url, expired }: SubRenewProps) {
  return (
    <Alert
      className="sub-renew"
      type={expired ? 'error' : 'warning'}
      showIcon
      title={expired ? 'আপনার সাবস্ক্রিপশনের মেয়াদ বা ডাটা শেষ' : 'সাবস্ক্রিপশন শেষ হতে চলেছে'}
      description="চালু রাখতে WhatsApp-এ যোগাযোগ করে রিনিউ করুন।"
      action={
        <Button
          type="primary"
          size="small"
          icon={<WhatsAppOutlined aria-hidden />}
          href={url}
          target="_blank"
          rel="noopener noreferrer"
        >
          রিনিউ করুন
        </Button>
      }
    />
  );
}
