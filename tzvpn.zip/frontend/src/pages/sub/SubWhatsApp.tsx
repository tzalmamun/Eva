import { WhatsAppOutlined } from '@ant-design/icons';

import { TZ_VPN_WHATSAPP_URL } from './subPageModel';

export default function SubWhatsApp() {
  return (
    <a
      className="sub-whatsapp"
      href={TZ_VPN_WHATSAPP_URL}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="WhatsApp"
      title="WhatsApp"
    >
      <WhatsAppOutlined aria-hidden />
    </a>
  );
}
