import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Alert, Button, Segmented } from 'antd';
import { AndroidOutlined, AppleOutlined } from '@ant-design/icons';

import { APP_ICONS } from './appIcons';
import type { AppPlatform, SubApp } from './subPageModel';

interface SubAppsTabProps {
  apps: Record<AppPlatform, SubApp[]>;
  initialPlatform: AppPlatform;
  onOpen: (url: string) => void;
}

const PLATFORM_OPTIONS = [
  { value: 'android' as const, label: 'Android', icon: <AndroidOutlined aria-hidden /> },
  { value: 'ios' as const, label: 'iOS', icon: <AppleOutlined aria-hidden /> },
];

function AppIcon({ name }: { name: string }) {
  const icon = APP_ICONS[name];
  if (!icon) {
    return (
      <span className="sub-app-mark" aria-hidden="true">
        {name.charAt(0)}
      </span>
    );
  }
  if (icon.tinted) {
    const mask = `url("${icon.src}")`;
    return (
      <span className="sub-app-mark" aria-hidden="true">
        <span className="sub-app-glyph" style={{ maskImage: mask, WebkitMaskImage: mask }} />
      </span>
    );
  }
  return <img className="sub-app-logo" src={icon.src} alt="" width={32} height={32} />;
}

export default function SubAppsTab({ apps, initialPlatform, onOpen }: SubAppsTabProps) {
  const { t } = useTranslation();
  const [platform, setPlatform] = useState<AppPlatform>(initialPlatform);

  return (
    <div className="sub-apps">
      <Segmented<AppPlatform> value={platform} onChange={setPlatform} options={PLATFORM_OPTIONS} />
      <Alert
        className="sub-guide"
        type="info"
        showIcon
        title="ইনস্টল করার নিয়ম"
        description="১) অ্যাপটি ডাউনলোড ও ইনস্টল করুন। ২) 'Subscription' ট্যাব থেকে লিংক কপি করুন। ৩) অ্যাপে সাবস্ক্রিপশন যোগ করে লিংকটি পেস্ট করুন। অন্য অ্যাপের পাশের 'Add' চাপলে স্বয়ংক্রিয়ভাবে যোগ হবে।"
      />
      <div className="sub-app-grid">
        {apps[platform].map((app) => (
          <div key={app.name} className="sub-row">
            <AppIcon name={app.name} />
            <span className="sub-app-name">{app.name}</span>
            <Button type="primary" size="small" onClick={() => onOpen(app.url)}>
              {app.download ? t('download') : t('add')}
            </Button>
          </div>
        ))}
      </div>
    </div>
  );
}
